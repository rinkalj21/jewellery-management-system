import React, { useState } from 'react';
import './Contactus.css'; // Ensure this matches the filename
import cimg from './img/cimg.jpg'; // Adjust the path as necessary

const Contactus = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="Contactus" style={{ backgroundImage: `url(${cimg})` }}>
      <h1>Contact Us</h1>
      <p>Have any questions? We'd love to hear from you!</p>
      <form className="contact-form" onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Your Email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <textarea
          name="message"
          placeholder="Your Message"
          value={formData.message}
          onChange={handleChange}
          required
        ></textarea>
        {/* Button removed */}
      </form>
      <div className="contact-info">
        <h2>Our Location</h2>
        <p>123 Jewellery St, mumbai City, State 394601</p>
        <p>Email: contact@jewelry.com</p>
        <p>Phone: (123) 456-7890</p>
      </div>
    </div>
  );
};

export default Contactus;
